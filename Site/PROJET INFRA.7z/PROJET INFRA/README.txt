Vous trouverez notre rapport sur le projet dans RAPPORT PROJET INFRA.
Vous trouverez le powerpoint de la gestion de projet dans ORAL INFRA.
Vous trouverez les maquettes demandées dans le dossier Maquettes.
Vous trouverez le site web dans le dossier Site.
Le site web n'est pas en ligne mais il est partageable à quelqu'un du même réseau à partir de notre
serveur Apache.

Ce travail à été réalisé par Nathan Couespel, Matéo Perrot--Nasi et Alexandre Rocchi